IF OBJECT_ID('IncidentFact', 'U') IS NOT NULL
DROP TABLE IncidentFact;

IF OBJECT_ID('DateDim', 'U') IS NOT NULL 
DROP TABLE DateDim;

IF OBJECT_ID('VictimDim', 'U') IS NOT NULL
DROP TABLE VictimDim;

IF OBJECT_ID('LocationDim', 'U') IS NOT NULL
DROP TABLE LocationDim;

IF OBJECT_ID('WeaponDim', 'U') IS NOT NULL
DROP TABLE WeaponDim;

IF OBJECT_ID('CauseDim', 'U') IS NOT NULL
DROP TABLE CauseDim;

IF OBJECT_ID('PoliceDim', 'U') IS NOT NULL
DROP TABLE PoliceDim;

IF OBJECT_ID ('DateDim', 'U') IS NOT NULL
DROP TABLE DateDim

CREATE TABLE DateDim (
   Date_ID INT NOT NULL PRIMARY KEY, 
   [Full_date] DATE NOT NULL,     
   [Day_of_week] TINYINT NOT NULL, 
   [Day_of_week_name] VARCHAR(10) NOT NULL, 
   [Month] TINYINT NOT NULL,     
   [Month_name] VARCHAR(10) NOT NULL,   
   [Quarter] TINYINT NOT NULL,  
   [Quarter_name] VARCHAR(6) NOT NULL,  
   [Year] INT NOT NULL, 
   [Month_year] CHAR(7) NOT NULL, 
   )

SET NOCOUNT ON

TRUNCATE TABLE DateDim

DECLARE @CurrentDate DATE = '2013-01-01'   
DECLARE @EndDate DATE = '2020-09-05'

WHILE @CurrentDate < @EndDate
BEGIN
   INSERT INTO DateDim (
      [Date_ID],
      [Full_date],
      [Day_of_week],
      [Day_of_week_name],
      [Month],
      [Month_name],
      [Quarter],
      [Quarter_name],
      [Year],
      [Month_year]
      )
   SELECT Date_ID = YEAR(@CurrentDate) * 10000 + MONTH(@CurrentDate) * 100 + DAY(@CurrentDate),
      Full_date = @CurrentDate,
      
      Day_of_week = DATEPART(dw, @CurrentDate),
      Day_of_week_name = DATENAME(dw, @CurrentDate),
      [Month] = MONTH(@CurrentDate),
      [Month_name] = DATENAME(mm, @CurrentDate),
      [Quarter] = DATEPART(q, @CurrentDate),
      [Quarter_name] = CASE 
         WHEN DATENAME(qq, @CurrentDate) = 1
            THEN 'First'
         WHEN DATENAME(qq, @CurrentDate) = 2
            THEN 'second'
         WHEN DATENAME(qq, @CurrentDate) = 3
            THEN 'third'
         WHEN DATENAME(qq, @CurrentDate) = 4
            THEN 'fourth'
         END,
      [Year] = YEAR(@CurrentDate),
      [Month_year] = CAST(YEAR(@CurrentDate) AS VARCHAR(4)) + UPPER(LEFT(DATENAME(mm, @CurrentDate), 3))
      

   SET @CurrentDate = DATEADD(DD, 1, @CurrentDate)
END

CREATE TABLE [VictimDim] (
    [Victim_ID] float PRIMARY KEY,
    [Victim_name] nvarchar(255),
    [Victim_age] nvarchar(255),
    [Victim_gender] nvarchar(255),
    [Victim_race] nvarchar(255),
    [Criminal_charges] nvarchar(255),
    [Symptoms_of_mental_illness] nvarchar(255)
)

CREATE TABLE [LocationDim] (
    [Location_ID] float PRIMARY KEY,
    [Street_address_of_incident] nvarchar(255),
    [City_of_incident] nvarchar(255),
    [County_of_incident] nvarchar(255),
    [State_of_incident] nvarchar(255),
    [Geography] nvarchar(255)
)

CREATE TABLE [WeaponDim] (
    [Weapon_ID] float PRIMARY KEY,
    [Description_of_weapon] nvarchar(255),
    [Weapon_name] nvarchar(255)
)

CREATE TABLE [CauseDim] (
    [Cause_ID] float PRIMARY KEY,
    [Cause_of_incident] nvarchar(255)
)

CREATE TABLE [PoliceDim] (
    [Police_ID] float PRIMARY KEY,
    [Police_department] nvarchar(255),
	[Official_disposition_of_death] nvarchar(255)
)

CREATE TABLE [IncidentFact] (
    [Incident_ID] int IDENTITY(1,1) PRIMARY KEY,  
    [Victim_ID] float FOREIGN KEY REFERENCES VictimDim(Victim_ID),
    [Location_ID] float FOREIGN KEY REFERENCES LocationDim(Location_ID),
    [Weapon_ID] float FOREIGN KEY REFERENCES WeaponDim(Weapon_ID),
    [Cause_ID] float FOREIGN KEY REFERENCES CauseDim(Cause_ID),
    [Police_ID] float FOREIGN KEY REFERENCES PoliceDim(Police_ID),
    [Date_ID] int FOREIGN KEY REFERENCES DateDim(Date_ID)
)
